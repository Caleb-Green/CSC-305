
package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@SpringBootApplication
@RestController
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    // Generate a secret key for AES encryption
    private static final String AES = "AES";
    private static SecretKeySpec secretKey;

    static {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance(AES);
            keyGen.init(128);
            SecretKey secretKeyTemp = keyGen.generateKey();
            byte[] raw = secretKeyTemp.getEncoded();
            secretKey = new SecretKeySpec(raw, AES);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Encrypt the given text using AES
    public static String encrypt(String strToEncrypt) {
        try {
            Cipher cipher = Cipher.getInstance(AES);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Decrypt the given text using AES
    public static String decrypt(String strToDecrypt) {
        try {
            Cipher cipher = Cipher.getInstance(AES);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping("/checksum")
    public String getChecksum() {
        String data = "Hello World Check Sum!";
        String encryptedData = encrypt(data);
        return "Original: " + data + " | Encrypted: " + encryptedData;
    }
}
